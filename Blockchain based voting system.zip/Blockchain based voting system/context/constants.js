//organizerAddress = '0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266'

import voting from "./Create.json";

export const VotingAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
export const VotingAddressABI = voting.abi;
