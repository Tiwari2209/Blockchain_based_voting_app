module.exports = {
  reactStrictMode: true,
  images: {
    domains: ["daulat-nft-marketplace.infura-ipfs.io"],
    formats: ["image/webp"],
  },
};
